#Twilio Details

account_sid = 'AC0bae7858471e5ffdb8b789a4a9094512'
auth_token = '6725bee455d0a3c8edec50b543f27e73'
twilionumber = '+12184754646'
twiliosmsnumber = '+18889923508'

#FC Bot
API_TOKEN = "2028472441:AAHi5mLFnrj_zMkhYP8YOPpcFU523-vP3gY"

#Host URL
callurl = 'https://a3702bf898c2.ngrok.io'
twiliosmsurl = 'https://a3702bf898c2.ngrok.io/sms'









